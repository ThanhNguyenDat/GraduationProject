#include "../inc/jtest_cycle.h"
#include <inttypes.h>

/*--------------------------------------------------------------------------------*/
/* Define Module Variables */
/*--------------------------------------------------------------------------------*/

/* const char * JTEST_CYCLE_STRF = "Running: %s\nCycles: %" PRIu32 "\n"; */
const char * JTEST_CYCLE_STRF = "Cycles: %" PRIu32 "\n"; /* function name + parameter string skipped */
