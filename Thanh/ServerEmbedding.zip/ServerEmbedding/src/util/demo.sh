gcc demo-connection.c -o demo-connection -lmysqlclient
./demo-connection